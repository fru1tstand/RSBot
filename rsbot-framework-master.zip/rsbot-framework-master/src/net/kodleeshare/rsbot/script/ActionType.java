package net.kodleeshare.rsbot.script;

public enum ActionType {
	CAMERA, MOUSE
}
