package net.kodleeshare.rsbot.script.modulescript;

public interface ScriptPattern {
	public void runPattern();
}
