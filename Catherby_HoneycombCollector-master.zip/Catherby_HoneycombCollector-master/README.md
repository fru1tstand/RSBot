Catherby_HoneycombCollector
===========================
